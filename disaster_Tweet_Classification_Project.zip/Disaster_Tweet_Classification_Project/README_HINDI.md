# Disaster Tweet Classification — Setup Guide (Hindi)

## Project kya karta hai?
Yeh NLP (Natural Language Processing) aur Machine Learning project tweet ke text ko do classes mein classify karta hai:
- `0` = Non-disaster
- `1` = Disaster-related

Ismein data exploration, text cleaning, TF-IDF, Logistic Regression aur Random Forest comparison, cross-validation, test metrics, charts aur Flask web interface shamil hain.

## Important: dataset file
Aapke upload mein Google Sheets ka `.mhtml` saved webpage snapshot mila, actual Excel workbook nahi. Training ke liye actual `.xlsx` ya `.csv` file chahiye.
Google Sheets kholen → **File → Download → Microsoft Excel (.xlsx)** ya **Comma-separated values (.csv)**.
Downloaded file ko is folder mein rakhein aur naam `twitter_disaster.xlsx` ya `twitter_disaster.csv` rakhein.

Expected columns:
- `text`: tweet text
- `target`: label (0 ya 1)

Agar columns ke naam alag hain, code kuch common names (`tweet`, `content`, `message`, `label`, `class`) bhi samajhta hai. Label values 0/1 honi chahiye ya common text labels jaise disaster/non-disaster.

## Windows / VS Code par kaise chalayein
1. Project ZIP extract karein.
2. Project folder VS Code mein open karein.
3. Terminal → New Terminal.
4. Python 3.13 select karna recommended hai, kyunki aapke environment mein Python 3.15 par kuch data-science packages ki availability issue kar sakti hai.
5. Neeche ke commands ek-ek karke chalayein:

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python train_model.py
python app.py
```

Agar PowerShell activation block kare, current terminal ke liye yeh command try karein:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```
Agar `py -3.13` available na ho to `py -0` chala kar installed versions dekhein; phir us version ko use karein jisme packages install ho sakte hain.

6. Training successful hone par metrics aur charts `reports` folder mein aur trained model `models` folder mein save honge.
7. Terminal mein Flask local URL dikhega, aam taur par `http://127.0.0.1:5000`. Use browser mein kholen.
8. Tweet paste karke **Classify Tweet** dabayein.

## Output files
- `reports/data_summary.json` — data rows aur class counts
- `reports/class_distribution.png` — class balance chart
- `reports/disaster_keyword_frequency.csv` — frequent terms
- `reports/model_comparison.csv` — model scores
- `reports/confusion_matrix.png`, `roc_curve.png`, `precision_recall_curve.png`
- `reports/classification_report.txt` — precision/recall/F1
- `models/disaster_tweet_model.joblib` — saved model

## Submission checklist
- [ ] Actual dataset `.xlsx`/`.csv` added
- [ ] `python train_model.py` runs without error
- [ ] `reports` folder contains metrics and charts
- [ ] `python app.py` launches website
- [ ] Test several example tweets
- [ ] Fill student name, roll number, course, college and submission date in report
- [ ] Do not write invented accuracy values; copy actual scores from `reports/model_comparison.csv`

## Limitations
This is a prototype, not a live Twitter stream monitor. It does not fetch tweets from X/Twitter. Model predictions can be wrong; do not use it as the sole basis for emergency response.
